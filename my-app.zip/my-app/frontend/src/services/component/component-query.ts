export class ComponentQuery {
	type?: string;
	search?: string;
}
