export class LoginDto {
	public email: string;
	public password: string;
}
