export class SuccessLoginDto {
	public accessToken: string;
}
