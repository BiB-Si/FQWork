import { ComponentType } from './types';

export class GetComponentTypeDto {
	id: number;
	name: ComponentType;
	required: boolean;
}
