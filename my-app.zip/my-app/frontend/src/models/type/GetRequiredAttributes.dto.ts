export class GetRequiredAttributesDto {
	name: string;
	list?: string[];
}
