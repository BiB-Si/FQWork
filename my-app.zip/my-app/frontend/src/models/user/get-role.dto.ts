export class GetRoleDto {
	public name: string;
	public description?: string;
}