export class UpdateUserDto {
	public firstName?: string;
	public lastName?: string;
	public email?: string
	public photo?: File | null
}