<?php

namespace App\Core\Components;

abstract class Component
{
    public readonly array $attributes;
    public readonly string $name;
}
